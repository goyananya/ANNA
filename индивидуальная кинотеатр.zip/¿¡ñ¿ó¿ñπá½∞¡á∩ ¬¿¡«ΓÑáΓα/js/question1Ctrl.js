app.controller('question1Ctrl', function($scope) {
    $scope.typeOfQuestions1 = [
        "ужасы",
        "романтика",
        "комедия",
        "триллер",
        "боевик",
        "детектив",
        "Другой жанр"
    ];
});