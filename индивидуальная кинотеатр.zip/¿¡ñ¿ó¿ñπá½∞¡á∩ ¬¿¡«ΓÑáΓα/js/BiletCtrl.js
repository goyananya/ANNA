app.controller('BiletCtrl', function($scope) {
    $scope.services = [
        { "title": "Веном","data": "20 октября","time": "5:50", "price": 50, "image": "image/kino/1.jpg" },
        { "title": "Игра в кальмара","data": "21 октября","time": "5:50", "price": 500, "image": "image/kino/2.jpg" },
        { "title": "Бумажный дом","data": "22 октбяря","time": "5:50", "price": 390, "image": "image/kino/3.jpg" },
        { "title": "Суперсемейка 2","data": "23 октября","time": "5:50", "price": 50, "image": "image/kino/4.jpg" },
        { "title": "Ведьмак","data": "23 октября", "time": "5:50","price": 550, "image": "image/kino/5.jpg" },
        { "title": "Королевская игра","data": "24 октября","time": "5:50", "price": 250, "image": "image/kino/6.jpg" },
        { "title": "Всем парням, которых я любила","data": "26 октября","time": "5:50", "price": 100, "image": "image/kino/7.jpg" },
        { "title": "Очень странные дела 3","data": "1 ноября", "price": 600, "image": "image/kino/8.jpg" },
        { "title": "Половое воспитание 18+","data": "4 ноября","time": "5:50", "price": 1000, "image": "image/kino/9.jpg" },
        { "title": "Босс молокососс ","data": "4 ноября","time": "6:10", "price": 1000, "image": "image/kino/10.jpg" },
        { "title": "Семейка Аддамс","data": "5 ноября","time": "5:50", "price": 1000, "image": "image/kino/11.jpg" },
        { "title": "Душа","data": "6 ноября","time": "5:50", "price": 1000, "image": "image/kino/12.jpg" },
        { "title": "Донор","data": "8 ноября","time": "5:50", "price": 1000, "image": "image/kino/13.jpg" },
        { "title": "Ральф против Интернета","data": "9 ноября","time": "5:50", "price": 1000, "image": "image/kino/14.jpg" },
        { "title": "Райя и последний дракон","data": "12 ноября","time": "5:50", "price": 1000, "image": "image/kino/15.jpg" },
        { "title": "Спеши любить","data": "7 ноября","time": "5:50", "price": 1000, "image": "image/kino/16.jpg" },
        { "title": "В метре от друг друга","data": "18 ноября","time": "5:50", "price": 1000, "image": "image/kino/17.jpg" },
        { "title": "Форма голоса","data": "15 ноября","time": "5:50", "price": 1000, "image": "image/kino/18.jpg" },
        { "title": "Твоё имя","data": "30 ноября","time": "5:50", "price": 1000, "image": "image/kino/19.jpg" },
        { "title": "Виноваты звёзды","data": "3 декабря","time": "5:50", "price": 1000, "image": "image/kino/20.jpg" },
          ];

    $scope.inputLogin = "";
    $scope.inputPass = "";

    $scope.login = "anyag";
    $scope.password = "cinoteatrg";
    $scope.isSignIn = false;
   
    $scope.editing = false;


    $scope.signIn = function() {
        if ($scope.inputLogin === $scope.login) {
            if ($scope.inputPass == $scope.password) {
                $scope.isSignIn = true;
                document.getElementById('myModal').style.display = "none"
            }
        }
    };
  

    $scope.removeProduct = function(itemTitle) {
        const index = $scope.services.findIndex(x => x.title === itemTitle);

        $scope.services.splice(index, 1);

        console.log(index);
    }
	


    $scope.addNewService = function() {
        newService = {
            title: "Unknown",
            price: 0,
            image: "images/logos/logo.jpg"
        }

        $scope.services.push(newService);
    }


    $scope.orderByMe = function(item) {
        $scope.myOrderBy = item;
        $scope.reverseOrder();
    }

    $scope.myReverseBy = false;
    $scope.reverseOrder = function() {
        $scope.myReverseBy = !($scope.myReverseBy);
    }


});

