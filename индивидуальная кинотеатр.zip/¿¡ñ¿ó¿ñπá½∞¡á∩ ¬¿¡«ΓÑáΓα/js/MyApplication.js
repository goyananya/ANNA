var app = angular.module('MyApplication', []);
app.service('ageService', function () {
    this.check = function (x) {
        if (x === NaN) {
            return "";
        }

    }
});


app.directive("test", function() {
    return {
        template : "<h3><b>Билет</b></h3>"
    };
});

app.filter('myFilterAge', ['ageService', function (ageService) {
    return function (x) {
        return ageService.check(x);
    };
}]);